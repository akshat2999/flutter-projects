package com.example.gymnash_owner

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
